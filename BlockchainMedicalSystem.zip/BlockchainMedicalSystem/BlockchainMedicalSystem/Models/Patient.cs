using System;
using System.Collections.Generic;          // ✅ REQUIRED
using System.ComponentModel.DataAnnotations;

namespace BlockchainMedicalSystem.Models
{
    public class Patient
    {
        [Key]
        public int PatientId { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;

        [Required]
        public int Age { get; set; }

        [Required]
        public string Gender { get; set; } = string.Empty;

        // ✅ Navigation: Patient → Bills
        public ICollection<Bill> Bills { get; set; } = new List<Bill>();

        [Required]
        public string MedicalRecord { get; set; } = string.Empty;

        [Required]
        public string Address { get; set; } = string.Empty;

        [Required]
        [Phone]
        public string ContactNumber { get; set; } = string.Empty;

        public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;

        public string Hash { get; set; } = string.Empty;
    }
}
