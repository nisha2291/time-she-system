using System;

namespace BlockchainMedicalSystem.Models
{
    public class TamperAlert
    {
        public int TamperAlertId { get; set; }

        public int PatientId { get; set; }

        public string EntityName { get; set; } = "Patient";   // ✅ matches DB column

        public string Message { get; set; } = "";

        public DateTime DetectedAt { get; set; } = DateTime.UtcNow;
    }
}
