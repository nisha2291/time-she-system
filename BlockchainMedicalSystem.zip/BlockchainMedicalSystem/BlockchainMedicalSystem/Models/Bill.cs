

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BlockchainMedicalSystem.Models
{
    public class Bill
    {
        [Key]
        public int BillId { get; set; }

        // ✅ Foreign Key (required)
        [Required]
        public int PatientId { get; set; }

        // ✅ Navigation property (connects Bill → Patient)
        [ForeignKey(nameof(PatientId))]


public Patient? Patient { get; set; }



        public string Source { get; set; } = "Hospital";






        [Required]
        [Column(TypeName = "decimal(18,2)")] // ✅ fixes huge decimal issue
        public decimal Amount { get; set; }

        [Required]
        public string Description { get; set; } = string.Empty;

        public DateTime BillDate { get; set; } = DateTime.UtcNow;

        // 🔗 Blockchain fields
        public string? PreviousHash { get; set; }
        public string? Hash { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public string CreatedBy { get; set; } = "Medical";
    }
}
