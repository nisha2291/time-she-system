using System;

namespace BlockchainMedicalSystem.Models
{
    public class AuditLog
    {
        public int AuditLogId { get; set; }
        public string Action { get; set; } = "";
        public string Actor { get; set; } = "";
        public string EntityName { get; set; } = "";
        public int? EntityId { get; set; }
        public string Details { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string IpAddress { get; set; } = "";
    }
}
