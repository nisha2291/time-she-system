using BlockchainMedicalSystem.Data;
using BlockchainMedicalSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace BlockchainMedicalSystem.Services
{
    public class BlockchainService
    {
        private readonly AppDbContext _context;

        public BlockchainService(AppDbContext context)
        {
            _context = context;
        }

        // ============================
        // SHA256 → lowercase hex
        // ============================
        private static string ComputeSha256Hex(string input)
        {
            using var sha = SHA256.Create();
            var bytes = Encoding.UTF8.GetBytes(input);
            var hash = sha.ComputeHash(bytes);

            var sb = new StringBuilder(hash.Length * 2);
            foreach (var b in hash)
                sb.Append(b.ToString("x2"));

            return sb.ToString();
        }

        // ============================
        // RAW DATA FORMAT (VERY IMPORTANT)
        // ============================
        // MUST be used everywhere (prepare, validate, repair)
        private static string BuildRaw(Bill bill)
        {
            return $"{bill.PatientId}|{bill.Amount}|{bill.Description}|{bill.BillDate:o}|{bill.CreatedBy}|{bill.PreviousHash}";
        }

        // ============================
        // CREATE HASH FOR NEW BILL
        // ============================
        public async Task<Bill> PrepareBillAsync(Bill bill)
        {
            var lastBill = await _context.Bills
                .Where(b => b.PatientId == bill.PatientId)
                .OrderByDescending(b => b.BillId)
                .FirstOrDefaultAsync();

            bill.PreviousHash = lastBill?.Hash ?? "GENESIS";
            bill.Timestamp = DateTime.UtcNow;

            string raw = BuildRaw(bill);
            bill.Hash = ComputeSha256Hex(raw);

            return bill;
        }

        // ============================
        // VALIDATE CHAIN (LINK + HASH)
        // ============================
        public async Task<bool> ValidateChainAsync(int patientId)
        {
            var bills = await _context.Bills
                .Where(b => b.PatientId == patientId)
                .OrderBy(b => b.BillId)
                .AsNoTracking()
                .ToListAsync();

            string prev = "GENESIS";

            foreach (var bill in bills)
            {
                // 1️⃣ check linkage
                if ((bill.PreviousHash ?? "") != prev)
                    return false;

                // 2️⃣ recompute hash
                var temp = new Bill
                {
                    PatientId = bill.PatientId,
                    Amount = bill.Amount,
                    Description = bill.Description,
                    BillDate = bill.BillDate,
                    CreatedBy = bill.CreatedBy,
                    PreviousHash = bill.PreviousHash
                };

                string expected = ComputeSha256Hex(BuildRaw(temp));
                string actual = bill.Hash ?? "";

                if (!string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase))
                    return false;

                prev = actual;
            }

            return true;
        }

        // ============================
        // REPAIR BROKEN CHAINS (ONE-TIME)
        // ============================
        public async Task RepairChainAsync(int patientId)
        {
            var bills = await _context.Bills
                .Where(b => b.PatientId == patientId)
                .OrderBy(b => b.BillId)
                .ToListAsync();

            string prev = "GENESIS";

            foreach (var bill in bills)
            {
                bill.PreviousHash = prev;
                bill.Timestamp = bill.Timestamp == default ? DateTime.UtcNow : bill.Timestamp;

                string raw = BuildRaw(bill);
                bill.Hash = ComputeSha256Hex(raw);

                prev = bill.Hash;
            }

            await _context.SaveChangesAsync();
        }
    }
}
