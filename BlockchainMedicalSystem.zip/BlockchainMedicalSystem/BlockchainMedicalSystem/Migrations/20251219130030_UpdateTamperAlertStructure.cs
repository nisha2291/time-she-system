﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BlockchainMedicalSystem.Migrations
{
    /// <inheritdoc />
    public partial class UpdateTamperAlertStructure : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PatientId",
                table: "TamperAlerts",
                newName: "EntityId");

            migrationBuilder.RenameColumn(
                name: "DetectedBy",
                table: "TamperAlerts",
                newName: "EntityName");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "EntityName",
                table: "TamperAlerts",
                newName: "DetectedBy");

            migrationBuilder.RenameColumn(
                name: "EntityId",
                table: "TamperAlerts",
                newName: "PatientId");
        }
    }
}
