using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BlockchainMedicalSystem.Data;
using BlockchainMedicalSystem.Models;

namespace BlockchainMedicalSystem.Controllers
{
    public class SecurityController : Controller
    {
        private readonly AppDbContext _context;

        public SecurityController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /Security/Alerts
        public async Task<IActionResult> Alerts()
        {
            var alerts = await _context.TamperAlerts
                .OrderByDescending(t => t.DetectedAt)
                .Take(50)
                .AsNoTracking()
                .ToListAsync();

            return View(alerts);
        }

        // GET: /Security/Audit
        public async Task<IActionResult> Audit()
        {
            var logs = await _context.AuditLogs
                .OrderByDescending(a => a.Timestamp)
                .Take(100)
                .AsNoTracking()
                .ToListAsync();

            return View(logs);
        }

        // GET: /Security/Report?patientId=12
        public async Task<IActionResult> Report(int patientId)
        {
            // 1) Load bills for this patient
            var bills = await _context.Bills
                .Where(b => b.PatientId == patientId)
                .OrderBy(b => b.BillId)
                .AsNoTracking()
                .ToListAsync();

            bool valid = true;

            // 2) Verify chain + hash
            if (bills.Count > 0)
            {
                string prev = "GENESIS";

                foreach (var bill in bills)
                {
                    string billPrev = bill.PreviousHash ?? "";

                    // Chain linkage check
                    if (!string.Equals(billPrev, prev, StringComparison.Ordinal))
                    {
                        valid = false;
                        break;
                    }

                    // IMPORTANT: This raw string must match how you generated hashes originally
                    string raw =
                        $"{bill.PatientId}|{bill.Amount}|{bill.Description}|{bill.BillDate:o}|{bill.CreatedBy}|{billPrev}";

                    string expected = ComputeSha256Hex(raw);
                    string actual = bill.Hash ?? "";

                    // Hash check
                    if (!string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase))
                    {
                        valid = false;
                        break;
                    }

                    prev = actual;
                }
            }

            // 3) If invalid => ALWAYS store AuditLog, TamperAlert only once
            if (!valid)
            {
                // ✅ ALWAYS insert AuditLog (every time invalid happens)
                _context.AuditLogs.Add(new AuditLog
                {
                    Timestamp = DateTime.UtcNow,
                    Actor = "SecuritySystem",
                    Action = "INTEGRITY_CHECK_FAILED",
                    EntityName = "Patient",
                    EntityId = patientId,
                    Details = "Blockchain hash verification failed",
                    IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "Unknown"
                });

                // ✅ Insert TamperAlert only once (avoid duplicates)
                bool already = await _context.TamperAlerts.AnyAsync(t =>
                    t.PatientId == patientId &&
                    (t.EntityName ?? "") == "Patient" &&
                    (t.Message ?? "").ToLower().Contains("integrity")
                );

                if (!already)
                {
                    _context.TamperAlerts.Add(new TamperAlert
                    {
                        PatientId = patientId,
                        EntityName = "Patient",
                        DetectedAt = DateTime.UtcNow,
                        Message = $"Integrity check failed for PatientId={patientId}. Possible tampering detected."
                    });
                }

                // ✅ Save both (AuditLog always + TamperAlert if needed)
                await _context.SaveChangesAsync();
            }

            // Send info to view
            ViewBag.PatientId = patientId;
            ViewBag.IsValid = valid;
            ViewBag.Count = bills.Count;

            return View(bills);
        }

        // Helper: SHA256 -> lowercase hex
        private static string ComputeSha256Hex(string input)
        {
            using var sha = SHA256.Create();
            byte[] bytes = Encoding.UTF8.GetBytes(input);
            byte[] hash = sha.ComputeHash(bytes);

            var sb = new StringBuilder(hash.Length * 2);
            foreach (var b in hash)
                sb.Append(b.ToString("x2"));

            return sb.ToString();
        }
    }
}
