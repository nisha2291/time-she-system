using BlockchainMedicalSystem.Data;
using BlockchainMedicalSystem.Models;
using BlockchainMedicalSystem.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BlockchainMedicalSystem.Controllers
{
    public class BillController : Controller
    {
        private readonly AppDbContext _context;
        private readonly BlockchainService _blockchain;

        public BillController(AppDbContext context, BlockchainService blockchain)
        {
            _context = context;
            _blockchain = blockchain;
        }

        // ============================
        // GET: Bill/Index
        // ============================
        public async Task<IActionResult> Index()
        {
            var bills = await _context.Bills
                .Include(b => b.Patient)
                .OrderByDescending(b => b.BillId)
                .AsNoTracking()
                .ToListAsync();

            return View(bills);
        }

        // ============================
        // GET: Bill/Create
        // ============================
        public async Task<IActionResult> Create()
        {
            ViewBag.Patients = await _context.Patients
                .OrderBy(p => p.Name)
                .AsNoTracking()
                .ToListAsync();

            return View(new Bill());
        }

        // ============================
        // POST: Bill/Create
        // ============================
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Bill bill)
        {
            // Always reload dropdown
            ViewBag.Patients = await _context.Patients
                .OrderBy(p => p.Name)
                .AsNoTracking()
                .ToListAsync();

            // Validation
            if (bill.PatientId <= 0)
                ModelState.AddModelError(nameof(Bill.PatientId), "Please select a patient.");

            if (bill.Amount <= 0)
                ModelState.AddModelError(nameof(Bill.Amount), "Amount must be greater than 0.");

            if (string.IsNullOrWhiteSpace(bill.Description))
                ModelState.AddModelError(nameof(Bill.Description), "Description is required.");

            bool patientExists = await _context.Patients
                .AnyAsync(p => p.PatientId == bill.PatientId);

            if (!patientExists)
                ModelState.AddModelError(nameof(Bill.PatientId), "Selected patient does not exist.");

            if (!ModelState.IsValid)
                return View(bill);

            // Server-side values (CRITICAL)
            bill.CreatedBy = "Medical";
            bill.BillDate = DateTime.UtcNow;

            // Blockchain
            await _blockchain.PrepareBillAsync(bill);

            // Save
            _context.Bills.Add(bill);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
