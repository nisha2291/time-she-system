using BlockchainMedicalSystem.Data;
using BlockchainMedicalSystem.Models;
using BlockchainMedicalSystem.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BlockchainMedicalSystem.Controllers
{
    public class InsuranceController : Controller
    {
        private readonly AppDbContext _context;
        private readonly BlockchainService _blockchain;

        public InsuranceController(AppDbContext context, BlockchainService blockchain)
        {
            _context = context;
            _blockchain = blockchain;
        }

        // GET: /Insurance/Search
        public IActionResult Search()
        {
            return View();
        }

        // POST: /Insurance/Search
        [HttpPost]
        public IActionResult Search(int patientId)
        {
            return RedirectToAction(nameof(Verify), new { patientId });
        }

        // GET: /Insurance/Verify?patientId=12
        public async Task<IActionResult> Verify(int patientId)
        {
            var patient = await _context.Patients.FirstOrDefaultAsync(p => p.PatientId == patientId);
            if (patient == null) return NotFound("Patient not found");

            var hospitalBills = await _context.Bills
                .Where(b => b.PatientId == patientId && b.Source == "Hospital")
                .OrderBy(b => b.BillId)
                .ToListAsync();

            var patientBills = await _context.Bills
                .Where(b => b.PatientId == patientId && b.Source == "Patient")
                .OrderBy(b => b.BillId)
                .ToListAsync();

            bool chainOk = await _blockchain.ValidateChainAsync(patientId);

            // Comparison (simple and clear for project)
            int matches = 0;
            int mismatches = 0;

            foreach (var hb in hospitalBills)
            {
                bool found = patientBills.Any(pb =>
                    pb.Amount == hb.Amount &&
                    (pb.Description ?? "").Trim().ToLower() == (hb.Description ?? "").Trim().ToLower());

                if (found) matches++;
                else mismatches++;
            }

            ViewBag.Patient = patient;
            ViewBag.HospitalBills = hospitalBills;
            ViewBag.PatientBills = patientBills;
            ViewBag.ChainOk = chainOk;
            ViewBag.Matches = matches;
            ViewBag.Mismatches = mismatches;

            return View();
        }

        // GET: /Insurance/AddPatientBill?patientId=12
        public IActionResult AddPatientBill(int patientId)
        {
            return View(new Bill
            {
                PatientId = patientId,
                Amount = 0,
                Description = "",
                BillDate = DateTime.UtcNow,
                CreatedBy = "Insurance",
                Source = "Patient"
            });
        }

        // POST: /Insurance/AddPatientBill
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddPatientBill(Bill bill)
        {
            // Force insurance values
            bill.CreatedBy = "Insurance";
            bill.Source = "Patient";

            if (!ModelState.IsValid)
                return View(bill);

            // Hash it too (tamper-evident)
            await _blockchain.PrepareBillAsync(bill);

            _context.Bills.Add(bill);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Verify), new { patientId = bill.PatientId });
        }
    }
}

