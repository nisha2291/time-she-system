using BlockchainMedicalSystem.Data;
using BlockchainMedicalSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace BlockchainMedicalSystem.Controllers
{
    public class PatientController : Controller
    {
        private readonly AppDbContext _context;

        public PatientController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Patient
        public async Task<IActionResult> Index()
        {
            var patients = await _context.Patients.ToListAsync();
            return View(patients);
        }

        // GET: Patient/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Patient/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Patient patient)
        {
            if (!ModelState.IsValid)
                return View(patient);

            // ✅ Fill required fields that are NOT in your form
            patient.Address ??= "N/A";
            patient.ContactNumber ??= "N/A";
            patient.RegistrationDate = DateTime.UtcNow;

            // ✅ Compute blockchain hash AFTER setting required fields
            patient.Hash = ComputeHash(patient);

            _context.Patients.Add(patient);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Patient/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var patient = await _context.Patients
                .FirstOrDefaultAsync(p => p.PatientId == id.Value);

            if (patient == null) return NotFound();

            return View(patient);
        }

        // POST: Patient/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var patient = await _context.Patients.FindAsync(id);
            if (patient != null)
            {
                _context.Patients.Remove(patient);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        // -------------------------------
        // Blockchain hash function
        // -------------------------------
        private static string ComputeHash(Patient patient)
        {
            using var sha256 = SHA256.Create();

            // include all fields you care about for integrity
            string rawData =
                $"{patient.Name}|{patient.Age}|{patient.Gender}|{patient.MedicalRecord}|" +
                $"{patient.Address}|{patient.ContactNumber}|{patient.RegistrationDate:O}";

            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));

            // Hex string (easy to read + store)
            return Convert.ToHexString(bytes);
        }
    }
}
