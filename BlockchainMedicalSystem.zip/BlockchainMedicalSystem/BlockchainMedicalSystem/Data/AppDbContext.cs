using BlockchainMedicalSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace BlockchainMedicalSystem.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Patient> Patients { get; set; }
        public DbSet<Bill> Bills { get; set; }

        public DbSet<AuditLog> AuditLogs { get; set; }
        public DbSet<TamperAlert> TamperAlerts { get; set; }
    }
}
